#include"head.h"
#include"head1.h"
#include <unistd.h>

//双向循环链表
linklist init_node(void)  //创建一个指向NULL的头指针
{
	return NULL;
}

linklist new_node(char *p)  //创建一个新节点
{
	linklist new = calloc(1,sizeof(struct node));
	if(new!=NULL)
	{
		new->next=new->prev=new;
		new->data=p;
	}
	
	return new;
}

linklist add_node(linklist head,linklist new)  
{
	//开局直接把new放进去
	if(head==NULL)
	{
		head = new;
		new = NULL;
		return head;
	}
		
	new->prev = head->prev;
	new->next = head;
	
	head->prev = new;
	new->prev->next = new;
	
	return head;
}



