#include"head.h"
#include"head1.h"
#include"bmp.h"

void showbmp(char *bmp)
{
	
	int fd=open(bmp,O_RDWR);

	struct bitmap_header head;
	struct bitmap_info info;
	bzero(&head,sizeof(head));
	bzero(&info,sizeof(info));
	
	read(fd,&head,sizeof(head));
	read(fd,&info,sizeof(info));//将两个结构体读走，再读就是rgb的信息了
	
	int rgb_size= head.size -sizeof(head) -sizeof(info);  //rgb大小为文件大小减去前两个结构体大小
	
	char *rgb=calloc(1,rgb_size); //申请一块堆内存放rgb的信息
	
	int n=0;
	int total=0;
	
	while(1)                                //将图片信息读到rgb内存
	{
		n=read(fd,rgb+total,rgb_size);
		total=total+n;
		if(total==rgb_size)
		{
			break;
		}
	}
	
	

	int lcd=open("/dev/fb0",O_RDWR);  //打开屏幕
	
	struct fb_var_screeninfo  vsinfo;
	bzero(&vsinfo, sizeof(vsinfo));
	ioctl(lcd, FBIOGET_VSCREENINFO, &vsinfo);   // 将LCD设备参数信息放入svinfo中
	
/* 	printf("分辨率为%d*%d\n",vsinfo.xres,vsinfo.yres); */
	
	
	int lcd_w=vsinfo.xres;
	int lcd_h=vsinfo.yres;
	int dpp=vsinfo.bits_per_pixel;
	
	
	
	char *lcdmem=mmap(NULL,lcd_w*lcd_h*dpp/8,PROT_READ | PROT_WRITE, MAP_SHARED,lcd,0); //映射一块屏幕内存（这里大小为800*480* 32/8）
			bzero(lcdmem,lcd_w*lcd_h*dpp/8);     //清屏
	
	int path = ((3*info.width)%4==0) ? 0:(4-(3*info.width)%4);  //每行bmp要填充的字节数
	
	
	
	int w_min = (info.width<(lcd_w)) ? info.width : (lcd_w);
	int h_min = (info.height<(lcd_h)) ? info.height :(lcd_h) ;  //填充的长度和宽度取两者宽的最小者，这里x，y为在lcd屏上显示图片的起始坐标
	
	int bmp_line_size = 3*info.width+path;   //bmp图片每行的字节数
	int lcd_line_size = 4*lcd_w;             //lcd屏映射内存每行的字节数
	
	char *tem=rgb;
	char *tem1=lcdmem;
	
	rgb=rgb+bmp_line_size *(info.height-1);  //指向bmp图片的最后一行
	
	
	int x,y;             //如果图片比屏幕小自动居中
	if(info.width<lcd_w)
	{
		x=(lcd_w-info.width)/2;
		y=(lcd_h - info.height)/2;
	}
	else
	{
		x=0;
		y=0;
	}
	
	
	if(info.width<=lcd_w)
	{
	      lcdmem = lcdmem+4*(y*lcd_w+x);           //指向lcd屏（x，y）
	
	
	   for(int j=0;j<h_min;j++)     //填充的行数，取两者的高的最小者
	    {
		  for(int i=0;i<w_min;i++)   
		  {
			memcpy(lcdmem+i*4,rgb+i*3,3);//将一行bmp填到lcd，填充的长度取两者宽的最小者
		  }
		
		  lcdmem=lcdmem+lcd_line_size;          //指向下一行
		  rgb=rgb-bmp_line_size ;                   //指向上一行
		
	    }
	}
	
	else
	{
		  lcdmem = lcdmem+4*(y*lcd_w+x);
		for(int j=0;j<h_min;j++)     //填充的行数，取两者的高的最小者
	    {
		  for(int i=0;i<w_min;i++)   
		  {
			memcpy(lcdmem+i*4,rgb+(i*3+3),3);//将一行bmp填到lcd，填充的长度取两者宽的最小者
			
		  }
		
		  lcdmem=lcdmem+lcd_line_size;          //指向下一行
		  rgb=rgb-bmp_line_size ;                   //指向上一行
		  rgb=rgb-bmp_line_size ;                   
		}
	}
	
	munmap(tem1,lcd_w*lcd_h*dpp/8); 
	free(tem);
	close(fd);
	close(lcd);

	
	
}
