#include"head.h"
#include"head1.h"
#include <math.h>

#define LEFT   1
#define RIGHT  2
#define UP     3
#define DOWN   4 

int x = 0 , y = 0;
int get_motion(int tp)
{
	struct input_event buf;
	
	int x1 , y1;  //手指按下的坐标值
	int x2 , y2;      //手指松开的坐标值
	
	while(1)
	{
		read(tp , &buf , sizeof(buf));			     //读取数据
			if(buf.type == EV_ABS &&   		    // 获取到了一个绝对坐标的事件
			   buf.code == ABS_X )   			   // 获取到了一个触摸屏的X轴坐标
			x2 = buf.value ; 					  //一直读取的X坐标
		
		else if(buf.type == EV_ABS && 
		        buf.code == ABS_Y ) 
			y2 = buf.value ; 
		
		if(buf.type == EV_KEY &&  				// 获取了一个按键类型的事件
		   buf.code == BTN_TOUCH &&   		   //进一步确认: 是触摸屏的按压事件
		   buf.value == 1)                    // 按下
		{
			x1 = x2;                    //开始的X坐标
			y1 = y2;                   //开始的Y坐标
		}
		
		if(buf.type == EV_KEY &&                 // 获取了一个按键类型的事件
		   buf.code == BTN_TOUCH &&             //进一步确认: 是触摸屏的按压事件
		   buf.value == 0)                     //松开手指
		{
			
		
			//   (x`2 - y`2)>0   往左<45° 
			if( (x2 - x1)*(x2 - x1) > (y2 - y1)*(y2 - y1) && x2 < x1 )  //1 向左滑 
				return LEFT;
			else if( (x2 - x1)*(x2 - x1) > (y2 - y1)*(y2 - y1) && x2 > x1 )  //2 向右滑
				return RIGHT;
			else if( (x2 - x1)*(x2 - x1) < (y2 - y1)*(y2 - y1) && x2 < x1 )  //3 向上滑
				return UP;
			else if( (x2 - x1)*(x2 - x1) < (y2 - y1)*(y2 - y1) && x2 > x1 )  //4 向下滑
				return DOWN;

			break;
		}
	}
}

	   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   
		   