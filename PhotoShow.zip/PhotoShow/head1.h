#ifndef _HEAD1_H
#define _HEAD1_H
typedef struct node
{
	char *data;  //*s
	int number;	
	struct node *prev;
	struct node *next;
	
}*linklist;
linklist init_node(void);
linklist new_node(char *p);
linklist add_node(linklist head,linklist new);

void showbmp(char *bmp);
void showjpg(char *jpg,int x,int y);
int get_motion(int tp);

char *mode(struct stat *info);

#define LEFT   1
#define RIGHT  2
#define UP     3
#define DOWN   4 



#endif