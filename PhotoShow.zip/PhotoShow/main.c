#include"head.h"
#include"head1.h"

int main(int argc,char **argv)
{		

	if(argc != 2)
		{
			printf("请按正确用法打开一个目录!\n",argv[0]);		
			printf("例子： %s<目录>\n",argv[0]);
			exit(0);
		}
		struct stat info;       //存放文件信息
				bzero(&info, sizeof(info));			
		if(stat(argv[1], &info) == -1)
	{
		perror("获取指定文件属性失败");
		exit(0);
	}

	//if((info.st_mode&S_IFMT) != S_IFDIR)
	  if(!S_ISDIR(info.st_mode))
	{
		printf("给我的不是目录！走人！\n");
		exit(0);
	}
		

				linklist head=init_node();       //建一条空链表
			//打开目录，并循环地读取里面的目录项	
				DIR *dp = opendir(argv[1]);
				struct dirent *ep,*ep2; //指向目录项的指针
					
				
				chdir(argv[1]);    //进入
				printf("当前目录：%s\n",argv[1]);

	while(1)
	{
		     ep=ep2=readdir(dp);
			if(ep == NULL)
			{
				printf("\n");
				break;
			}	
			
// 1、(浏览目录)
			//ep2也是一个指向目录项的指针(浏览目录)
			if(ep2->d_name[0] == '.')     
					continue;

				// 获取当前文件的stat信息
				bzero(&info, sizeof(info));
				stat(ep2->d_name, &info);    //目录指针把文件信息放到info结构体里
				printf("%s: %ld\n", ep2->d_name, info.st_size);
		
				// ep是一个指向目录项的指针(处理图片)
		if(strstr(ep->d_name,".bmp")||strstr(ep->d_name,".jpg"))
		{
			linklist new = new_node(ep->d_name);    //给地址
			head = add_node(head,new);
		} 		
	}
	
	
	
	linklist p = head;
	if(p==	NULL)     //head没有得到图片数据
	{
		printf("%s目录下没有BMG、JPG的图片\n",argv[1]);
			exit(0);
	}
	
if(strstr(p->data,".bmp"))
	{
		showbmp(p->data);
	printf("打开%s\n",p->data);
	}
		
	if(strstr(p->data,".jpg"))	
	{
		showjpg(p->data,0,0);
		printf("打开%s\n",p->data);
	}	
	
	
 

	// 1，打开触摸屏
	int tp = open("/dev/input/event0", O_RDWR);

	// 获取文件当前的状态标签
	long flag = fcntl(tp, F_GETFL);

	// 将非阻塞标签加入到当前状态标签中
	flag |= O_NONBLOCK;

	// 重新设置文件的状态标签（此时含有非阻塞标签）
	fcntl(tp, F_SETFL, flag);

	while(1)
	{
		switch(get_motion(tp))
		{

			case LEFT: 
						printf("左滑\n");
						p=p->prev;
						
						if(strstr(p->data,".bmp"))
							showbmp(p->data);
						else
							showjpg(p->data,0,0);
						printf("打开%s\n",p->data);
						
												break;
			
			case RIGHT: 
						printf("右滑\n");
						p=p->next;
						
						if(strstr(p->data,".bmp"))
							showbmp(p->data);
						else
							showjpg(p->data,0,0);
						printf("打开%s\n",p->data);
												break;
				
			  case DOWN:     printf("上滑\n");   //由于LCD起始点在左上角，所以上下要反过来
							p=head;	
							showbmp(p->data);
								printf("返回初始位置%s\n",p->data);
												break;
			case UP:   printf("下滑\n");
			printf("终止程序！\n");
							exit(0);
		}
		
	}
	close(tp);

	return 0;
}
	

